// @/components/main/ContainerBoard.tsx
import React from "react";
import {
    LayoutTemplate, Trash2, Wand2, Plus,
    Bold, Italic, Underline, Link as LinkIcon, Box, AlignLeft, AlignCenter, AlignRight,
    Upload, Video, Music, ImageIcon, X, Merge, Split, Sparkles
} from "lucide-react";
import { ContainerNode, ElementNode, TableData } from "@/types/types";

interface ContainerBoardProps {
    containers: ContainerNode[];
    setContainers: (containers: ContainerNode[]) => void;
    activeElementId: string | null;
    setActiveElementId: (id: string | null) => void;
    setLayoutModalOpen: (isOpen: boolean) => void;
    setElementModalOpen: (modal: { containerId: string; columnId: string } | null) => void;
    openAnimModal: (container: ContainerNode) => void;

    // 핸들러 함수들
    deleteElement: (containerId: string, columnId: string, elementId: string) => void;
    handleFileUpload: (containerId: string, columnId: string, elementId: string, file: File) => void;
    updateElementStyle: (containerId: string, columnId: string, elementId: string, key: any, value: any) => void;
    updateElementProps: (containerId: string, columnId: string, elementId: string, category: 'styles' | 'buttonStyles' | 'tableData' | 'cardData', key: string, value: any) => void;
    updateElementHtmlContent: (elementId: string, htmlContent: string) => void;
    applyStyleToSelection: (styleType: any, value: any) => boolean;
    handleSelection: () => void;
    handleResizeStart: (e: React.MouseEvent, containerId: string, columnId: string, el: ElementNode, direction: string) => void;

    // 테이블 관련
    selectedCells: Set<string>;
    setSelectedCells: (cells: Set<string> | ((prev: Set<string>) => Set<string>)) => void;
    isDraggingCell: boolean;
    setIsDraggingCell: (isDragging: boolean) => void;
    mergeCells: (containerId: string, columnId: string, elementId: string, tableData: TableData) => void;
    unmergeCells: (containerId: string, columnId: string, elementId: string, cellKey: string, tableData: TableData) => void;
    getCommonBorderWidth: (tableData: TableData) => number;
    getCommonBorderColor: (tableData: TableData) => string;
    applyToTableCells: (containerId: string, columnId: string, elementId: string, tableData: TableData, key: any, value: any) => void;
    savedRangeRef: React.MutableRefObject<Range | null>;

    // [AI 추가] 모달 제어 프롭스
    setAiModalOpen?: (isOpen: boolean) => void;
}

export default function ContainerBoard({
    containers, setContainers, activeElementId, setActiveElementId,
    setLayoutModalOpen, setElementModalOpen, openAnimModal,
    deleteElement, handleFileUpload, updateElementStyle, updateElementProps, updateElementHtmlContent,
    applyStyleToSelection, handleSelection, handleResizeStart,
    selectedCells, setSelectedCells, isDraggingCell, setIsDraggingCell,
    mergeCells, unmergeCells, getCommonBorderWidth, getCommonBorderColor, applyToTableCells, savedRangeRef,
    setAiModalOpen
}: ContainerBoardProps) {

    const getWidthClass = (width: string) => {
        switch (width) {
            case "1/1": return "w-full"; case "1/2": return "w-1/2"; case "1/3": return "w-1/3";
            case "2/3": return "w-2/3"; case "1/4": return "w-1/4"; case "3/4": return "w-3/4";
            default: return "w-full";
        }
    };

    return (
        <div className="space-y-6 min-h-[500px]">
            {containers.map((container) => (
                <div key={container.id} className="border border-slate-300 bg-white">
                    <div className="bg-[#1e88e5] flex items-center justify-between px-3 py-1.5 text-white">
                        <span className="text-sm font-semibold flex items-center gap-2">
                            <LayoutTemplate size={16} /> Container
                            {container.animation && container.animation.type !== 'none' && (
                                <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full ml-2">
                                    {container.animation.type}
                                </span>
                            )}
                        </span>
                        <div className="flex items-center gap-1">
                            <button onClick={() => openAnimModal(container)} className="p-1.5 hover:bg-white/20 rounded transition" title="애니메이션 설정">
                                <Wand2 size={14} />
                            </button>
                            <button onClick={() => setContainers(containers.filter((c) => c.id !== container.id))} className="p-1.5 hover:bg-red-500 rounded transition" title="삭제">
                                <Trash2 size={14} />
                            </button>
                        </div>
                    </div>

                    <div className="flex flex-wrap p-4 gap-4 bg-slate-50">
                        {container.columns.map((column) => (
                            <div key={column.id} className={`${getWidthClass(column.width)} flex-shrink-0 flex flex-col gap-1 relative`} style={{ width: `calc(${eval(column.width) * 100}% - 0.5rem)` }}>

                                {column.elements.map((el) => {
                                    const isActive = activeElementId === el.id;

                                    return (
                                        <div key={el.id} className={`element-box relative flex w-full ${el.type === 'TEXT' ? 'py-1 px-4' : 'p-4'}`} style={{ justifyContent: el.styles?.layerAlign || 'flex-start' }}>

                                            {/* 1. TEXT Element */}
                                            {el.type === "TEXT" && el.styles && (
                                                <div
                                                    id={`element-${el.id}`}
                                                    className={`relative group inline-block ${isActive ? 'outline outline-2 outline-[#00d0d0]' : 'hover:outline hover:outline-1 hover:outline-slate-300'}`}
                                                    onMouseDown={(e) => {
                                                        e.stopPropagation();
                                                        if (activeElementId !== el.id) setActiveElementId(el.id);
                                                    }}
                                                    style={{
                                                        width: el.styles.width === "auto" ? "100%" : `${el.styles.width}px`,
                                                        height: el.styles.height === "auto" ? "auto" : `${el.styles.height}px`,
                                                    }}
                                                >
                                                    {isActive && (
                                                        <div className="absolute -top-16 left-1/2 -translate-x-1/2 bg-white rounded-lg shadow-xl border border-slate-200 px-3 py-2 flex items-center gap-2 z-50 whitespace-nowrap element-toolbar">
                                                            <select
                                                                value={el.styles.fontFamily}
                                                                onChange={(e) => {
                                                                    const val = e.target.value;
                                                                    const isApplied = applyStyleToSelection('fontFamily', val);
                                                                    if (!isApplied) updateElementStyle(container.id, column.id, el.id, "fontFamily", val);
                                                                }}
                                                                className="border border-slate-200 rounded p-1 text-xs font-bold text-slate-700 outline-none cursor-pointer"
                                                            >
                                                                <option value="default">기본 폰트</option>
                                                                <option value="var(--font-noto-sans)">Noto Sans KR</option>
                                                                <option value="var(--font-nanum-gothic)">나눔고딕</option>
                                                                <option value="var(--font-gothic-a1)">Gothic A1</option>
                                                                <option value="var(--font-black-han-sans)">검은고딕</option>
                                                                <option value="var(--font-nanum-myeongjo)">나눔명조</option>
                                                                <option value="var(--font-gowun-batang)">고운바탕</option>
                                                                <option value="var(--font-jua)">주아체</option>
                                                                <option value="var(--font-do-hyeon)">도현체</option>
                                                                <option value="var(--font-nanum-pen-script)">나눔손글씨 펜</option>
                                                            </select>
                                                            <div className="w-px h-4 bg-slate-300" />
                                                            <div className="flex items-center gap-1">
                                                                <input
                                                                    type="number"
                                                                    value={el.styles.fontSize}
                                                                    onChange={(e) => {
                                                                        const val = Number(e.target.value);
                                                                        const isApplied = applyStyleToSelection('fontSize', val);
                                                                        if (!isApplied) updateElementStyle(container.id, column.id, el.id, "fontSize", val);
                                                                    }}
                                                                    className="w-12 text-center text-xs font-bold border border-slate-200 rounded outline-none py-1"
                                                                />
                                                                <span className="text-[10px] text-slate-400">px</span>
                                                            </div>
                                                            <div className="w-px h-4 bg-slate-300" />
                                                            <input
                                                                type="color"
                                                                value={el.styles.color}
                                                                onChange={(e) => {
                                                                    const val = e.target.value;
                                                                    const isApplied = applyStyleToSelection('color', val);
                                                                    if (!isApplied) updateElementStyle(container.id, column.id, el.id, "color", val);
                                                                }}
                                                                className="w-5 h-5 p-0 border-none rounded cursor-pointer"
                                                            />
                                                            <div className="w-px h-4 bg-slate-300" />
                                                            <div className="flex items-center gap-0.5 bg-slate-100 p-0.5 rounded">
                                                                <button onMouseDown={(e) => e.preventDefault()} onClick={() => updateElementStyle(container.id, column.id, el.id, "textAlign", "left")} className={`p-1 rounded ${el.styles.textAlign === 'left' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`} title="텍스트 좌측 정렬"><AlignLeft size={14} /></button>
                                                                <button onMouseDown={(e) => e.preventDefault()} onClick={() => updateElementStyle(container.id, column.id, el.id, "textAlign", "center")} className={`p-1 rounded ${el.styles.textAlign === 'center' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`} title="텍스트 가운데 정렬"><AlignCenter size={14} /></button>
                                                                <button onMouseDown={(e) => e.preventDefault()} onClick={() => updateElementStyle(container.id, column.id, el.id, "textAlign", "right")} className={`p-1 rounded ${el.styles.textAlign === 'right' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`} title="텍스트 우측 정렬"><AlignRight size={14} /></button>
                                                            </div>
                                                            <div className="w-px h-4 bg-slate-300" />
                                                            <div className="flex items-center gap-0.5 bg-slate-100 p-0.5 rounded">
                                                                <button
                                                                    onMouseDown={(e) => e.preventDefault()}
                                                                    onClick={() => {
                                                                        const newVal = el.styles!.fontWeight === "bold" ? "normal" : "bold";
                                                                        const isApplied = applyStyleToSelection('fontWeight', newVal);
                                                                        if (!isApplied) updateElementStyle(container.id, column.id, el.id, "fontWeight", newVal);
                                                                    }}
                                                                    className={`p-1 rounded ${el.styles!.fontWeight === 'bold' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`}
                                                                    title="굵게"
                                                                >
                                                                    <Bold size={14} />
                                                                </button>
                                                                <button
                                                                    onMouseDown={(e) => e.preventDefault()}
                                                                    onClick={() => {
                                                                        const newVal = el.styles!.fontStyle === "italic" ? "normal" : "italic";
                                                                        const isApplied = applyStyleToSelection('fontStyle', newVal);
                                                                        if (!isApplied) updateElementStyle(container.id, column.id, el.id, "fontStyle", newVal);
                                                                    }}
                                                                    className={`p-1 rounded ${el.styles!.fontStyle === 'italic' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`}
                                                                    title="이탤릭"
                                                                >
                                                                    <Italic size={14} />
                                                                </button>
                                                                <button
                                                                    onMouseDown={(e) => e.preventDefault()}
                                                                    onClick={() => {
                                                                        const newVal = el.styles!.textDecoration === "underline" ? "none" : "underline";
                                                                        const isApplied = applyStyleToSelection('textDecoration', newVal);
                                                                        if (!isApplied) updateElementStyle(container.id, column.id, el.id, "textDecoration", newVal);
                                                                    }}
                                                                    className={`p-1 rounded ${el.styles!.textDecoration === 'underline' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`}
                                                                    title="밑줄"
                                                                ><Underline size={14} /></button>
                                                                <button
                                                                    onMouseDown={(e) => e.preventDefault()}
                                                                    onClick={() => {
                                                                        if (savedRangeRef.current && activeElementId) {
                                                                            const url = window.prompt("선택한 글자에 연결할 웹사이트 주소를 입력하세요:", "https://");
                                                                            if (url) applyStyleToSelection('link', url);
                                                                        } else {
                                                                            alert("링크를 걸 글자를 먼저 드래그하여 선택해주세요.");
                                                                        }
                                                                    }}
                                                                    className="p-1 rounded text-slate-500 hover:bg-white hover:shadow-sm hover:text-indigo-600"
                                                                    title="링크 걸기 (글자 드래그 후 클릭)"
                                                                ><LinkIcon size={14} /></button>
                                                            </div>
                                                            <div className="w-px h-4 bg-slate-300" />
                                                            <div className="flex items-center gap-0.5 bg-slate-100 p-0.5 rounded">
                                                                <button onMouseDown={(e) => e.preventDefault()} onClick={() => updateElementStyle(container.id, column.id, el.id, "layerAlign", "flex-start")} className={`p-1 rounded ${el.styles.layerAlign === 'flex-start' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`} title="박스 좌측 배치"><Box size={14} /></button>
                                                                <button onMouseDown={(e) => e.preventDefault()} onClick={() => updateElementStyle(container.id, column.id, el.id, "layerAlign", "center")} className={`p-1 rounded ${el.styles.layerAlign === 'center' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`} title="박스 중앙 배치"><AlignCenter size={14} /></button>
                                                                <button onMouseDown={(e) => e.preventDefault()} onClick={() => updateElementStyle(container.id, column.id, el.id, "layerAlign", "flex-end")} className={`p-1 rounded ${el.styles.layerAlign === 'flex-end' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`} title="박스 우측 배치"><Box size={14} /></button>
                                                            </div>
                                                            <div className="w-px h-4 bg-slate-300" />
                                                            <button onMouseDown={(e) => e.preventDefault()} onClick={() => deleteElement(container.id, column.id, el.id)} className="text-slate-500 hover:text-red-500" title="삭제"><Trash2 size={16} /></button>
                                                        </div>
                                                    )}

                                                    {isActive && (
                                                        <>
                                                            <div onMouseDown={(e) => handleResizeStart(e, container.id, column.id, el, 'nw')} className="absolute -top-1.5 -left-1.5 w-3 h-3 bg-white border-2 border-[#00d0d0] rounded-full cursor-nwse-resize z-10" />
                                                            <div onMouseDown={(e) => handleResizeStart(e, container.id, column.id, el, 'ne')} className="absolute -top-1.5 -right-1.5 w-3 h-3 bg-white border-2 border-[#00d0d0] rounded-full cursor-nesw-resize z-10" />
                                                            <div onMouseDown={(e) => handleResizeStart(e, container.id, column.id, el, 'sw')} className="absolute -bottom-1.5 -left-1.5 w-3 h-3 bg-white border-2 border-[#00d0d0] rounded-full cursor-nesw-resize z-10" />
                                                            <div onMouseDown={(e) => handleResizeStart(e, container.id, column.id, el, 'se')} className="absolute -bottom-1.5 -right-1.5 w-3 h-3 bg-white border-2 border-[#00d0d0] rounded-full cursor-nwse-resize z-10" />
                                                        </>
                                                    )}

                                                    <div
                                                        id={`editable-${el.id}`}
                                                        contentEditable
                                                        suppressContentEditableWarning
                                                        onMouseUp={handleSelection}
                                                        onKeyUp={handleSelection}
                                                        onBlur={(e) => {
                                                            if (e.relatedTarget && (e.relatedTarget as HTMLElement).closest('.element-toolbar')) {
                                                                return;
                                                            }
                                                            updateElementHtmlContent(el.id, e.currentTarget.innerHTML);
                                                        }}
                                                        style={{
                                                            fontSize: `${el.styles.fontSize}px`,
                                                            color: el.styles.color,
                                                            textAlign: el.styles.textAlign,
                                                            fontFamily: el.styles.fontFamily !== 'default' ? el.styles.fontFamily : 'inherit',
                                                            outline: 'none',
                                                            fontWeight: el.styles.fontWeight || 'normal',
                                                            fontStyle: el.styles.fontStyle || 'normal',
                                                            textDecoration: el.styles.textDecoration || 'none',
                                                            width: '100%',
                                                            height: '100%'
                                                        }}
                                                        className="px-2 cursor-text whitespace-pre-wrap"
                                                        dangerouslySetInnerHTML={{ __html: el.content }}
                                                    />
                                                </div>
                                            )}

                                            {/* 2. IMAGE Element */}
                                            {el.type === "IMAGE" && (
                                                <div className="w-full relative group">
                                                    {el.content ? (
                                                        <div className="relative border rounded overflow-hidden">
                                                            <img src={el.content} alt="업로드 이미지" className="w-full h-auto object-cover max-h-64" />
                                                            <button onClick={() => deleteElement(container.id, column.id, el.id)} className="absolute top-2 right-2 p-1 bg-red-600 text-white rounded shadow hover:bg-red-700">
                                                                <Trash2 size={14} />
                                                            </button>
                                                        </div>
                                                    ) : (
                                                        <label
                                                            onDragOver={(e) => e.preventDefault()}
                                                            onDrop={(e) => {
                                                                e.preventDefault();
                                                                if (e.dataTransfer.files?.[0]) handleFileUpload(container.id, column.id, el.id, e.dataTransfer.files[0]);
                                                            }}
                                                            className="h-40 bg-slate-50 flex flex-col items-center justify-center text-slate-400 border-2 border-dashed border-slate-300 rounded cursor-pointer hover:border-indigo-500 hover:bg-indigo-50/20 transition w-full"
                                                        >
                                                            <Upload size={28} className="mb-2 text-indigo-500" />
                                                            <span className="text-xs font-bold text-slate-700">이미지를 드래그하거나 클릭하여 업로드</span>
                                                            <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleFileUpload(container.id, column.id, el.id, e.target.files[0])} />
                                                        </label>
                                                    )}
                                                </div>
                                            )}

                                            {/* 3. VIDEO Element */}
                                            {el.type === "VIDEO" && (
                                                <div className="w-full relative">
                                                    {el.content ? (
                                                        <div className="relative border rounded overflow-hidden bg-black">
                                                            <video src={el.content} controls className="w-full max-h-64 object-contain" />
                                                            <button onClick={() => deleteElement(container.id, column.id, el.id)} className="absolute top-2 right-2 p-1 bg-red-600 text-white rounded shadow hover:bg-red-700">
                                                                <Trash2 size={14} />
                                                            </button>
                                                        </div>
                                                    ) : (
                                                        <label
                                                            onDragOver={(e) => e.preventDefault()}
                                                            onDrop={(e) => {
                                                                e.preventDefault();
                                                                if (e.dataTransfer.files?.[0]) handleFileUpload(container.id, column.id, el.id, e.dataTransfer.files[0]);
                                                            }}
                                                            className="h-40 bg-slate-50 flex flex-col items-center justify-center text-slate-400 border-2 border-dashed border-slate-300 rounded cursor-pointer hover:border-indigo-500 hover:bg-indigo-50/20 transition w-full"
                                                        >
                                                            <Video size={28} className="mb-2 text-indigo-500" />
                                                            <span className="text-xs font-bold text-slate-700">동영상 파일을 드래그하거나 클릭하여 업로드</span>
                                                            <input type="file" accept="video/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleFileUpload(container.id, column.id, el.id, e.target.files[0])} />
                                                        </label>
                                                    )}
                                                </div>
                                            )}

                                            {/* 4. AUDIO Element */}
                                            {el.type === "AUDIO" && (
                                                <div className="w-full relative">
                                                    {el.content ? (
                                                        <div className="relative border rounded p-4 bg-white flex flex-col gap-2 w-full">
                                                            <audio src={el.content} controls className="w-full" />
                                                            <button onClick={() => deleteElement(container.id, column.id, el.id)} className="absolute top-2 right-2 p-1 bg-red-600 text-white rounded shadow hover:bg-red-700">
                                                                <Trash2 size={14} />
                                                            </button>
                                                        </div>
                                                    ) : (
                                                        <label
                                                            onDragOver={(e) => e.preventDefault()}
                                                            onDrop={(e) => {
                                                                e.preventDefault();
                                                                if (e.dataTransfer.files?.[0]) handleFileUpload(container.id, column.id, el.id, e.dataTransfer.files[0]);
                                                            }}
                                                            className="h-32 bg-slate-50 flex flex-col items-center justify-center text-slate-400 border-2 border-dashed border-slate-300 rounded cursor-pointer hover:border-indigo-500 hover:bg-indigo-50/20 transition w-full"
                                                        >
                                                            <Music size={28} className="mb-2 text-indigo-500" />
                                                            <span className="text-xs font-bold text-slate-700">오디오 파일을 드래그하거나 클릭하여 업로드</span>
                                                            <input type="file" accept="audio/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleFileUpload(container.id, column.id, el.id, e.target.files[0])} />
                                                        </label>
                                                    )}
                                                </div>
                                            )}

                                            {/* 5. BUTTON Element */}
                                            {el.type === "BUTTON" && el.buttonStyles && (
                                                <div className="p-4 flex justify-center w-full relative" onMouseDown={(e) => { e.stopPropagation(); setActiveElementId(el.id); }}>
                                                    {isActive && (
                                                        <div className="absolute -top-16 left-1/2 -translate-x-1/2 bg-white rounded-lg shadow-xl border border-slate-200 px-3 py-2 flex items-center gap-3 z-50 whitespace-nowrap">
                                                            <input type="text" value={el.buttonStyles.text} onChange={(e) => updateElementProps(container.id, column.id, el.id, 'buttonStyles', 'text', e.target.value)} className="w-20 text-xs border border-slate-200 rounded px-1 py-1" />
                                                            <input type="color" value={el.buttonStyles.backgroundColor} onChange={(e) => updateElementProps(container.id, column.id, el.id, 'buttonStyles', 'backgroundColor', e.target.value)} className="w-5 h-5 cursor-pointer" />
                                                            <button onClick={() => deleteElement(container.id, column.id, el.id)} className="text-slate-500 hover:text-red-500"><Trash2 size={16} /></button>
                                                        </div>
                                                    )}
                                                    <button style={{ backgroundColor: el.buttonStyles.backgroundColor, color: el.buttonStyles.color, fontSize: `${el.buttonStyles.fontSize}px`, width: `${el.buttonStyles.width}px`, borderRadius: `${el.buttonStyles.borderRadius}px` }} className="px-6 py-2 shadow font-bold">
                                                        {el.buttonStyles.text}
                                                    </button>
                                                </div>
                                            )}

                                            {/* 6. SEPARATOR Element */}
                                            {el.type === "SEPARATOR" && (
                                                <div className="w-full h-4 border-b-2 border-dashed border-slate-300"></div>
                                            )}

                                            {/* 7. TABLE Element */}
                                            {el.type === "TABLE" && el.tableData && (
                                                <div
                                                    className="relative w-full overflow-x-auto pt-8 pb-4"
                                                    onMouseDown={(e) => {
                                                        e.stopPropagation();
                                                        setActiveElementId(el.id);
                                                    }}
                                                >
                                                    {isActive && (
                                                        <div className="absolute top-0 left-0 bg-white rounded-lg shadow-xl border border-slate-200 px-3 py-1.5 flex items-center gap-3 z-50">
                                                            {selectedCells.size > 1 && (
                                                                <button onClick={() => mergeCells(container.id, column.id, el.id, el.tableData!)} className="flex items-center gap-1 text-xs font-bold text-indigo-600 hover:text-indigo-800">
                                                                    <Merge size={14} /> 병합
                                                                </button>
                                                            )}
                                                            {selectedCells.size === 1 && (el.tableData!.cells[Array.from(selectedCells)[0]]?.rowSpan > 1 || el.tableData!.cells[Array.from(selectedCells)[0]]?.colSpan > 1) && (
                                                                <button onClick={() => unmergeCells(container.id, column.id, el.id, Array.from(selectedCells)[0], el.tableData!)} className="flex items-center gap-1 text-xs font-bold text-amber-600 hover:text-amber-800">
                                                                    <Split size={14} /> 해제
                                                                </button>
                                                            )}
                                                            <div className="w-px h-4 bg-slate-300" />
                                                            <div className="flex items-center gap-1">
                                                                <span className="text-[10px] font-bold text-slate-500">선 굵기</span>
                                                                <input
                                                                    type="number" min="0" max="10"
                                                                    value={getCommonBorderWidth(el.tableData!)}
                                                                    onChange={(e) => applyToTableCells(container.id, column.id, el.id, el.tableData!, 'borderWidth', Number(e.target.value))}
                                                                    className="w-10 text-center text-xs border border-slate-200 rounded py-0.5 outline-none"
                                                                />
                                                            </div>
                                                            <div className="w-px h-4 bg-slate-300" />
                                                            <div className="flex items-center gap-1">
                                                                <span className="text-[10px] font-bold text-slate-500">선 색상</span>
                                                                <input
                                                                    type="color"
                                                                    value={getCommonBorderColor(el.tableData!)}
                                                                    onChange={(e) => applyToTableCells(container.id, column.id, el.id, el.tableData!, 'borderColor', e.target.value)}
                                                                    className="w-5 h-5 p-0 border-none rounded cursor-pointer"
                                                                />
                                                            </div>
                                                            <div className="w-px h-4 bg-slate-300" />
                                                            <label className="flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-indigo-600 cursor-pointer" title="선택한 셀에 이미지 삽입">
                                                                <ImageIcon size={14} />
                                                                <span>이미지</span>
                                                                <input
                                                                    type="file"
                                                                    accept="image/*"
                                                                    className="hidden"
                                                                    onChange={(e) => {
                                                                        const file = e.target.files?.[0];
                                                                        if (!file) return;
                                                                        if (selectedCells.size === 0) {
                                                                            alert("이미지를 삽입할 테이블 셀을 먼저 선택해주세요.");
                                                                            return;
                                                                        }
                                                                        const fileUrl = URL.createObjectURL(file);
                                                                        const newCells = { ...el.tableData!.cells };
                                                                        selectedCells.forEach(cellKey => {
                                                                            if (newCells[cellKey]) {
                                                                                newCells[cellKey].content = `<img src="${fileUrl}" alt="table-img" style="max-width: 100%; height: auto; display: block; margin: 0 auto;" />`;
                                                                                newCells[cellKey].file = file
                                                                            }
                                                                        });
                                                                        updateElementProps(container.id, column.id, el.id, 'tableData', 'cells', newCells);
                                                                    }}
                                                                />
                                                            </label>
                                                            <div className="w-px h-4 bg-slate-300" />
                                                            <button
                                                                onMouseDown={(e) => e.preventDefault()}
                                                                onClick={() => {
                                                                    if (selectedCells.size === 0) {
                                                                        alert("링크를 걸 테이블 셀을 먼저 선택해주세요.");
                                                                        return;
                                                                    }
                                                                    const url = window.prompt("선택한 셀에 연결할 웹사이트 주소를 입력하세요:", "https://");
                                                                    if (!url) return;
                                                                    const newCells = { ...el.tableData!.cells };
                                                                    selectedCells.forEach(cellKey => {
                                                                        if (newCells[cellKey]) {
                                                                            const currentContent = newCells[cellKey].content;
                                                                            newCells[cellKey].content = `<a href="${url}" target="_blank" style="text-decoration: underline; color: #1e88e5;">${currentContent || '링크'}</a>`;
                                                                        }
                                                                    });
                                                                    updateElementProps(container.id, column.id, el.id, 'tableData', 'cells', newCells);
                                                                }}
                                                                className="flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-indigo-600"
                                                                title="선택한 셀 전체에 링크 씌우기"
                                                            >
                                                                <LinkIcon size={14} />
                                                                <span>링크</span>
                                                            </button>
                                                            <div className="w-px h-4 bg-slate-300" />
                                                            {selectedCells.size === 0 && <span className="text-[10px] text-slate-400 font-bold ml-1">셀을 드래그하여 병합</span>}
                                                            <div className="w-px h-4 bg-slate-300 ml-auto" />
                                                            <button onClick={() => deleteElement(container.id, column.id, el.id)} className="text-slate-500 hover:text-red-500"><Trash2 size={16} /></button>
                                                        </div>
                                                    )}
                                                    <table className={`w-full border-collapse bg-white ${isActive ? 'outline outline-2 outline-offset-2 outline-[#00d0d0]' : ''}`}>
                                                        <tbody>
                                                            {Array.from({ length: el.tableData!.rows }).map((_, r) => (
                                                                <tr key={r}>
                                                                    {Array.from({ length: el.tableData!.cols }).map((_, c) => {
                                                                        const cellKey = `${r}-${c}`;
                                                                        const cell = el.tableData!.cells[cellKey];
                                                                        if (!cell || !cell.isVisible) return null;
                                                                        const isSelected = selectedCells.has(cellKey);
                                                                        return (
                                                                            <td
                                                                                key={cellKey}
                                                                                rowSpan={cell.rowSpan}
                                                                                colSpan={cell.colSpan}
                                                                                onMouseDown={(e) => {
                                                                                    setActiveElementId(el.id);
                                                                                    if ((e.target as HTMLElement).tagName === 'TD' || (e.target as HTMLElement).tagName === 'TABLE') {
                                                                                        setIsDraggingCell(true);
                                                                                        setSelectedCells(new Set([cellKey]));
                                                                                    }
                                                                                }}
                                                                                onMouseEnter={() => {
                                                                                    if (isDraggingCell) setSelectedCells(prev => new Set(prev).add(cellKey));
                                                                                }}
                                                                                className={`p-2 min-w-[50px] transition-colors ${isSelected ? 'bg-indigo-100/60 outline outline-2 outline-indigo-500 z-10' : 'bg-white'}`}
                                                                                style={{
                                                                                    textAlign: cell.textAlign,
                                                                                    borderWidth: `${cell.borderWidth ?? 1}px`,
                                                                                    borderColor: cell.borderColor ?? '#cbd5e1',
                                                                                    borderStyle: 'solid'
                                                                                }}
                                                                            >
                                                                                <div
                                                                                    contentEditable
                                                                                    suppressContentEditableWarning
                                                                                    className="outline-none min-h-[20px] cursor-text"
                                                                                    onMouseDown={(e) => {
                                                                                        e.stopPropagation();
                                                                                        setActiveElementId(el.id);
                                                                                    }}
                                                                                    onBlur={(e) => {
                                                                                        const newCells = { ...el.tableData!.cells };
                                                                                        newCells[cellKey].content = e.currentTarget.innerHTML;
                                                                                        updateElementProps(container.id, column.id, el.id, 'tableData', 'cells', newCells);
                                                                                    }}
                                                                                    dangerouslySetInnerHTML={{ __html: cell.content }}
                                                                                />
                                                                            </td>
                                                                        );
                                                                    })}
                                                                </tr>
                                                            ))}
                                                        </tbody>
                                                    </table>
                                                </div>
                                            )}

                                            {/* 9. CARD Element */}
                                            {el.type === "CARD" && el.cardData && (
                                                <div className="w-full relative" onMouseDown={(e) => { e.stopPropagation(); setActiveElementId(el.id); }}>
                                                    {isActive && (
                                                        <div className="absolute -top-16 left-0 bg-white rounded-lg shadow-xl border border-slate-200 px-3 py-2 flex items-center gap-2 z-50 whitespace-nowrap overflow-x-auto">
                                                            <button onClick={() => updateElementProps(container.id, column.id, el.id, 'cardData', 'layout', el.cardData!.layout === 'row' ? 'col' : 'row')} className="px-2 py-1 text-xs bg-slate-100 hover:bg-slate-200 rounded font-bold text-slate-700">
                                                                {el.cardData.layout === 'row' ? '좌우 모드' : '위아래 모드'}
                                                            </button>
                                                            <div className="w-px h-4 bg-slate-300" />
                                                            <label className="text-xs font-bold text-indigo-600 cursor-pointer flex items-center gap-1">
                                                                <ImageIcon size={14} /> 아이콘
                                                                <input type="file" accept="image/*" className="hidden" onChange={(e) => {
                                                                    const file = e.target.files?.[0];
                                                                    if (file) {
                                                                        const url = URL.createObjectURL(file);
                                                                        setContainers(containers.map(c => c.id === container.id ? {
                                                                            ...c, columns: c.columns.map(col => col.id === column.id ? {
                                                                                ...col, elements: col.elements.map(element => element.id === el.id ? {
                                                                                    ...element, file: file, cardData: { ...element.cardData!, iconUrl: url }
                                                                                } : element)
                                                                            } : col)
                                                                        } : c));
                                                                    }
                                                                }} />
                                                            </label>
                                                            <div className="w-px h-4 bg-slate-300" />
                                                            <select
                                                                value={el.styles?.fontFamily || "default"}
                                                                onChange={(e) => {
                                                                    const val = e.target.value;
                                                                    const isApplied = applyStyleToSelection('fontFamily', val);
                                                                    if (!isApplied) updateElementStyle(container.id, column.id, el.id, "fontFamily", val);
                                                                }}
                                                                className="border border-slate-200 rounded p-1 text-xs font-bold text-slate-700 outline-none cursor-pointer"
                                                            >
                                                                <option value="default">기본 폰트</option>
                                                                <option value="var(--font-noto-sans)">Noto Sans KR</option>
                                                                <option value="var(--font-nanum-gothic)">나눔고딕</option>
                                                                <option value="var(--font-gothic-a1)">Gothic A1</option>
                                                                <option value="var(--font-black-han-sans)">검은고딕</option>
                                                                <option value="var(--font-nanum-myeongjo)">나눔명조</option>
                                                                <option value="var(--font-gowun-batang)">고운바탕</option>
                                                                <option value="var(--font-jua)">주아체</option>
                                                                <option value="var(--font-do-hyeon)">도현체</option>
                                                                <option value="var(--font-nanum-pen-script)">나눔손글씨 펜</option>
                                                            </select>
                                                            <div className="flex items-center gap-1">
                                                                <input
                                                                    key={`font-size-${el.id}`}
                                                                    type="number"
                                                                    defaultValue={el.styles?.fontSize || 16}
                                                                    onChange={(e) => {
                                                                        const val = Number(e.target.value);
                                                                        const isApplied = applyStyleToSelection('fontSize', val);
                                                                        if (!isApplied) {
                                                                            updateElementStyle(container.id, column.id, el.id, "fontSize", val);
                                                                        }
                                                                    }}
                                                                    className="w-12 text-center text-xs font-bold border border-slate-200 rounded outline-none py-1"
                                                                />
                                                                <span className="text-[10px] text-slate-400">px</span>
                                                            </div>
                                                            <input
                                                                type="color"
                                                                value={el.styles?.color || "#000000"}
                                                                onChange={(e) => {
                                                                    const val = e.target.value;
                                                                    const isApplied = applyStyleToSelection('color', val);
                                                                    if (!isApplied) updateElementStyle(container.id, column.id, el.id, "color", val);
                                                                }}
                                                                className="w-5 h-5 p-0 border-none rounded cursor-pointer"
                                                                title="글자 색상"
                                                            />
                                                            <div className="w-px h-4 bg-slate-300" />
                                                            <div className="flex items-center gap-0.5 bg-slate-100 p-0.5 rounded">
                                                                <button onMouseDown={(e) => e.preventDefault()} onClick={() => updateElementStyle(container.id, column.id, el.id, "textAlign", "left")} className={`p-1 rounded ${el.styles?.textAlign === 'left' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`} title="좌측 정렬"><AlignLeft size={14} /></button>
                                                                <button onMouseDown={(e) => e.preventDefault()} onClick={() => updateElementStyle(container.id, column.id, el.id, "textAlign", "center")} className={`p-1 rounded ${el.styles?.textAlign === 'center' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`} title="가운데 정렬"><AlignCenter size={14} /></button>
                                                                <button onMouseDown={(e) => e.preventDefault()} onClick={() => updateElementStyle(container.id, column.id, el.id, "textAlign", "right")} className={`p-1 rounded ${el.styles?.textAlign === 'right' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`} title="우측 정렬"><AlignRight size={14} /></button>
                                                            </div>
                                                            <div className="flex items-center gap-0.5 bg-slate-100 p-0.5 rounded">
                                                                <button onMouseDown={(e) => e.preventDefault()} onClick={() => updateElementProps(container.id, column.id, el.id, 'cardData', 'verticalAlign', 'flex-start')} className={`p-1.5 rounded text-xs font-bold ${el.cardData?.verticalAlign === 'flex-start' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`} title="상단 정렬">상</button>
                                                                <button onMouseDown={(e) => e.preventDefault()} onClick={() => updateElementProps(container.id, column.id, el.id, 'cardData', 'verticalAlign', 'center')} className={`p-1.5 rounded text-xs font-bold ${el.cardData?.verticalAlign === 'center' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`} title="중앙 정렬">중</button>
                                                                <button onMouseDown={(e) => e.preventDefault()} onClick={() => updateElementProps(container.id, column.id, el.id, 'cardData', 'verticalAlign', 'flex-end')} className={`p-1.5 rounded text-xs font-bold ${el.cardData?.verticalAlign === 'flex-end' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`} title="하단 정렬">하</button>
                                                            </div>
                                                            <div className="w-px h-4 bg-slate-300" />
                                                            <button onClick={() => deleteElement(container.id, column.id, el.id)} className="text-slate-500 hover:text-red-500"><Trash2 size={16} /></button>
                                                        </div>
                                                    )}
                                                    <div
                                                        style={{
                                                            borderStyle: 'solid',
                                                            borderWidth: `${el.cardData.borderWidth}px`,
                                                            borderColor: el.cardData.borderColor,
                                                            backgroundColor: el.cardData.backgroundColor,
                                                            borderRadius: `${el.cardData.borderRadius}px`,
                                                            padding: `${el.cardData.padding}px`,
                                                            alignItems: el.cardData.layout === 'col'
                                                                ? (el.styles?.textAlign === 'center' ? 'center' : el.styles?.textAlign === 'right' ? 'flex-end' : 'flex-start')
                                                                : (el.cardData.verticalAlign || 'center')
                                                        }}
                                                        className={`w-full transition-all flex gap-4 ${el.cardData.layout === 'col' ? 'flex-col items-start' : 'flex-row items-center'} ${el.cardData.shadow !== 'none' ? `shadow-${el.cardData.shadow}` : ''} ${isActive ? 'outline outline-2 outline-[#00d0d0]' : ''}`}
                                                    >
                                                        {el.cardData.iconUrl && (
                                                            <div className="flex-shrink-0 relative group">
                                                                <img src={el.cardData.iconUrl} style={{ width: el.cardData.iconSize, height: el.cardData.iconSize }} className="object-contain" alt="icon" />
                                                                <button
                                                                    onClick={() => updateElementProps(container.id, column.id, el.id, 'cardData', 'iconUrl', '')}
                                                                    className="absolute -top-2 -right-2 bg-red-500 text-white p-1 rounded-full text-[10px] hidden group-hover:block"
                                                                >
                                                                    <X size={12} />
                                                                </button>
                                                            </div>
                                                        )}
                                                        <div className="flex-grow w-full">
                                                            <div
                                                                id={`editable-${el.id}`}
                                                                contentEditable
                                                                suppressContentEditableWarning
                                                                onMouseUp={handleSelection}
                                                                onKeyUp={handleSelection}
                                                                style={{
                                                                    fontSize: el.styles?.fontSize ? `${el.styles.fontSize}px` : '16px',
                                                                    color: el.styles?.color || '#000000',
                                                                    textAlign: el.styles?.textAlign || 'left',
                                                                    fontFamily: el.styles?.fontFamily && el.styles.fontFamily !== 'default' ? el.styles.fontFamily : 'inherit',
                                                                    fontWeight: el.styles?.fontWeight || 'normal',
                                                                    fontStyle: el.styles?.fontStyle || 'normal',
                                                                    textDecoration: el.styles?.textDecoration || 'none',
                                                                }}
                                                                onBlur={(e) => updateElementHtmlContent(el.id, e.currentTarget.innerHTML)}
                                                                className="outline-none min-h-[50px] cursor-text w-full break-words"
                                                                dangerouslySetInnerHTML={{ __html: el.content }}
                                                            />
                                                        </div>
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                    );
                                })}

                                <button
                                    onClick={() => setElementModalOpen({ containerId: container.id, columnId: column.id })}
                                    className="flex items-center justify-center gap-2 border-2 border-dashed border-slate-300 text-slate-400 hover:text-indigo-600 hover:border-indigo-400 hover:bg-indigo-50 transition p-4 bg-white mt-auto"
                                >
                                    <Plus size={16} /> <span className="text-sm font-bold">Element</span>
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            ))}

            {/* ========================================== */}
            {/* [AI 추가] Container 추가 버튼 영역에 AI 생성 버튼 배치 */}
            {/* ========================================== */}
            <div className="flex justify-end mt-4 gap-2">
                {setAiModalOpen && (
                    <button
                        onClick={() => setAiModalOpen(true)}
                        className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-sm font-bold rounded shadow-sm hover:opacity-90 transition-opacity"
                    >
                        <Sparkles size={16} /> AI로 요소 생성
                    </button>
                )}
                <button
                    onClick={() => setLayoutModalOpen(true)}
                    className="flex items-center gap-2 px-4 py-2 border border-slate-300 bg-white text-slate-600 hover:bg-slate-50 text-sm font-bold rounded shadow-sm"
                >
                    <Plus size={16} /> Container
                </button>
            </div>
        </div>
    );
}